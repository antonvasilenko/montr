/* @flow */
import React, { Component } from 'react';
import { AppRegistry } from 'react-native';

import AppPage from './AppPage';

AppRegistry.registerComponent('AwesomeProject', () => AppPage);
