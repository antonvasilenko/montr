/* @flow */

import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  ListView,
  TouchableHighlight,
} from 'react-native';
import monitoringService from './../services/MonitoringService.js';
import bannerImage from './../../res/bottomBanner.png';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  welcome: {
    fontSize: 30,
    textAlign: 'center',
    margin: 10,
  },
  title: {
    color: 'black',
    fontWeight: 'bold',
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});

class AppPage extends Component {

    // Initialize the hardcoded data
  constructor(props) {
    super(props);
    const ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
    this.state = {
      dataSource: ds.cloneWithRows([
        'John', 'Joel', 'James', 'Jimmy', 'Jackson', 'Jillian', 'Julie', 'Devin',
        'John', 'Joel', 'James', 'Jimmy', 'Jackson', 'Jillian', 'Julie', 'Devin',
        'John', 'Joel', 'James', 'Jimmy', 'Jackson', 'Jillian', 'Julie', 'Devin',
      ]),
    };
  }

  buttonPressed = async () => {
    console.log('button pressed');
    const statuses = await monitoringService.getServiceStatus();
    this.setState({
      dataSource: this.state.dataSource.cloneWithRows(statuses.map(st => st.name)),
    });
  }

  renderRow = rowData => {
    const sx = { height: 20, backgroundColor: 'white' };
    return (<Text style={sx}>{rowData}</Text>);
  }

  render() {
    return (
      <View style={{ flex: 1 }}>
        <View
          style={{ flex: 1,
            backgroundColor: 'powderblue',
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
           }}
        >
          <Text style={{ backgroundColor: 'blue', padding: 5 }}>1</Text>
          <TouchableHighlight onPress={this.buttonPressed}>
            <Text style={{ backgroundColor: 'green', padding: 5 }}>Get Data</Text>
          </TouchableHighlight>
        </View>
        <View style={{ flex: 4 }}>
          <ListView
            dataSource={this.state.dataSource}
            renderRow={this.renderRow}
          />
        </View>
        <View style={{ flex: 1, backgroundColor: 'steelblue' }}>
          <Text style={[styles.welcome, styles.title]}>
            Welcome to React Native, {this.state.name}!
          </Text>
        </View>
        <Image
          source={bannerImage}
          style={{ flex: 1, alignSelf: 'flex-start', height: undefined }}
        />
      </View>
    );
  }
}

export default AppPage;
